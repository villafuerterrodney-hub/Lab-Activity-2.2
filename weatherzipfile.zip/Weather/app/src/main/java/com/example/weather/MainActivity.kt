@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weather

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WeatherScreen() }
    }
}

@Composable
fun WeatherScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New York Weather", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF00695C)
                )
            )
        }
    ) { padding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Text("New York", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Clouds", fontSize = 16.sp, color = Color.DarkGray)
                Text("broken clouds", fontSize = 14.sp, color = Color.Gray)
            }

            Image(
                painter = painterResource(id = R.drawable.ic_cloud),
                contentDescription = "Cloud Icon",
                modifier = Modifier.size(48.dp)
            )
        }
    }
}
